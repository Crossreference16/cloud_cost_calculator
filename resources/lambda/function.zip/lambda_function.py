def lambda_handler(event, context):
    print("Weekly cost report generated.")