import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    ce = boto3.client('ce')
    end = datetime.utcnow().date()
    start = end - timedelta(days=7)

    response = ce.get_cost_and_usage(
        TimePeriod={
            'Start': start.strftime('%Y-%m-%d'),
            'End': end.strftime('%Y-%m-%d')
        },
        Granularity='WEEKLY',
        Metrics=['UnblendedCost'],
        GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}]
    )

    print(f"AWS Cost Explorer results for {start} to {end}:")
    total = 0.0
    for group in response['ResultsByTime'][0]['Groups']:
        service = group['Keys'][0]
        amount = float(group['Metrics']['UnblendedCost']['Amount'])
        total += amount
        print(f"  {service}: ${amount:.2f}")
    print(f"Total: ${total:.2f}")
